require jquery
require jquery_ujs
require parallax
require jquery.parallax

$(function(){ $(document).foundation(); });

$('#scene').parallax();
